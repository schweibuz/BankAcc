CREATE FUNCTION date_part (text, abstime) RETURNS double precision
	LANGUAGE sql
AS $$
select pg_catalog.date_part($1, cast($2 as timestamp with time zone))
$$
