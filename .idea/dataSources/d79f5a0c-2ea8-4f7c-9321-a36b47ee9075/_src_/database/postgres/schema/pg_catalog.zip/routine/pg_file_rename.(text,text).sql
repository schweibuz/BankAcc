CREATE FUNCTION pg_file_rename (text, text) RETURNS boolean
	LANGUAGE sql
AS $$
SELECT pg_catalog.pg_file_rename($1, $2, NULL::pg_catalog.text);
$$
